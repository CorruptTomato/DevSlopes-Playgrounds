//: Playground - noun: a place where people can play

import UIKit

var welcomeMessage = "Hello, Welcome"

var number = 20

var decimal = 50.5

decimal = 20.23

let newDecimal = 40.5

var newMessage: String

newMessage = "hi this is a new message!"
