//: Playground - noun: a place where people can play

import UIKit

//Integer

var myBankAccount: Int = -500

var myAge: UInt = 22

var bigNumber: Int64 = 123123123123213

var aNum = 6

var anotherBankAccount: Double = 55.5
var someVal: Float = 5.5

var sum = anotherBankAccount * Double(someVal)

